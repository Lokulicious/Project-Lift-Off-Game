var class_g_x_p_engine_1_1_sound_channel =
[
    [ "SoundChannel", "class_g_x_p_engine_1_1_sound_channel.html#a0ee2ccecd0868808b7eb464c1c47b2d9", null ],
    [ "Stop", "class_g_x_p_engine_1_1_sound_channel.html#aa398367364ddf786a89587ce1823ad42", null ],
    [ "Frequency", "class_g_x_p_engine_1_1_sound_channel.html#a8df9e548ec167fa10bd0e8ec6b5e7c2b", null ],
    [ "IsPaused", "class_g_x_p_engine_1_1_sound_channel.html#a276233dd3ae6aac6502e935928fec728", null ],
    [ "IsPlaying", "class_g_x_p_engine_1_1_sound_channel.html#accd2841550a1d4f5ada901015f73937d", null ],
    [ "Mute", "class_g_x_p_engine_1_1_sound_channel.html#acbaa61db9096254ab2313efe7635ff63", null ],
    [ "Pan", "class_g_x_p_engine_1_1_sound_channel.html#aa32afc3ea5339ad1a22a9c433cf38847", null ],
    [ "Volume", "class_g_x_p_engine_1_1_sound_channel.html#a0ee86302e91b41a1706addf6dd156c01", null ]
];