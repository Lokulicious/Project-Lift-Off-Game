var searchData=
[
  ['renderrange_285',['RenderRange',['../class_g_x_p_engine_1_1_game.html#a7c90cb7f4df63b1fbc651c878caf7ddf',1,'GXPEngine::Game']]],
  ['rotation_286',['rotation',['../class_g_x_p_engine_1_1_transformable.html#ada9991b3de129aab7b679a9bc393e347',1,'GXPEngine::Transformable']]]
];
