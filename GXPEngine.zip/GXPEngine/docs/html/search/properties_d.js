var searchData=
[
  ['width_293',['width',['../class_g_x_p_engine_1_1_window.html#af9ce97573dc94e37fe3662ecc7ba8221',1,'GXPEngine.Window.width()'],['../class_g_x_p_engine_1_1_animation_sprite.html#a9c91d7d8f7f4683e9822b64f130a78d8',1,'GXPEngine.AnimationSprite.width()'],['../class_g_x_p_engine_1_1_game.html#a0a659aa4d59ed3729fc5d255651aac26',1,'GXPEngine.Game.width()'],['../class_g_x_p_engine_1_1_sprite.html#a6c1766de4d8d0b00dae6cadd5b577973',1,'GXPEngine.Sprite.width()']]],
  ['windowx_294',['windowX',['../class_g_x_p_engine_1_1_window.html#a831f8f665dd57d7bf56942fea0fe2f40',1,'GXPEngine::Window']]],
  ['windowy_295',['windowY',['../class_g_x_p_engine_1_1_window.html#aa7ea3483bb539781fc2ceaa09d1a1c44',1,'GXPEngine::Window']]]
];
