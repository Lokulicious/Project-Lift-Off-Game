﻿using GXPEngine;
using System.Collections;
using System;

namespace GXPEngine
{
    public class FilledWall : Sprite
    {
        public FilledWall() : base("FullWallTile.png")
        {

        }
    }
}