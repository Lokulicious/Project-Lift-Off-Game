var class_tiled_map_parser_1_1_tiled_object =
[
    [ "ToString", "class_tiled_map_parser_1_1_tiled_object.html#ac40d97643cc642074a84bf38d0b370da", null ],
    [ "GID", "class_tiled_map_parser_1_1_tiled_object.html#a57cd967e7feda0370d64f43bfe48d4a9", null ],
    [ "Height", "class_tiled_map_parser_1_1_tiled_object.html#aac2ed5c0c6e5607e0504857294ba9c2b", null ],
    [ "ID", "class_tiled_map_parser_1_1_tiled_object.html#af0a830c09f651a5917a327384669c289", null ],
    [ "Name", "class_tiled_map_parser_1_1_tiled_object.html#ac8b01340f2805978850b17991e273dad", null ],
    [ "textField", "class_tiled_map_parser_1_1_tiled_object.html#ac2e726b028c2f057bd1df9e1a0378e55", null ],
    [ "Type", "class_tiled_map_parser_1_1_tiled_object.html#a719122efe1f20d7c5136ab75874f7e90", null ],
    [ "Width", "class_tiled_map_parser_1_1_tiled_object.html#a02a654ea720e539d51907ef64e032c40", null ],
    [ "X", "class_tiled_map_parser_1_1_tiled_object.html#a3703e88cca485dec6c66973a2bb4ce30", null ],
    [ "Y", "class_tiled_map_parser_1_1_tiled_object.html#a185d906f75ee9fdeb7583495492c4483", null ]
];