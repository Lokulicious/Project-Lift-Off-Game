var searchData=
[
  ['scale_102',['scale',['../class_g_x_p_engine_1_1_transformable.html#aecff1ea2c666c1c869099f5715ef80d2',1,'GXPEngine::Transformable']]],
  ['scalex_103',['scaleX',['../class_g_x_p_engine_1_1_transformable.html#ae8467a6cf97a80d429641a3565846347',1,'GXPEngine::Transformable']]],
  ['scaley_104',['scaleY',['../class_g_x_p_engine_1_1_transformable.html#a9eca26b4d2a05a84bf058514178ac7b1',1,'GXPEngine::Transformable']]],
  ['setchildindex_105',['SetChildIndex',['../class_g_x_p_engine_1_1_game_object.html#aee5eda02a379782f6a1a6034c178fe71',1,'GXPEngine::GameObject']]],
  ['setcolor_106',['SetColor',['../class_g_x_p_engine_1_1_sprite.html#a1273156710bcf4143a80147a721a696d',1,'GXPEngine::Sprite']]],
  ['setframe_107',['SetFrame',['../class_g_x_p_engine_1_1_animation_sprite.html#ac1814eb56833aacf3ef62a93ed714fdd',1,'GXPEngine::AnimationSprite']]],
  ['setorigin_108',['SetOrigin',['../class_g_x_p_engine_1_1_sprite.html#a7f23dfc233b1a22c92ca548a5a6e7efc',1,'GXPEngine::Sprite']]],
  ['setscalexy_109',['SetScaleXY',['../class_g_x_p_engine_1_1_transformable.html#ac1fb7cad30e47d512c6e7ceeb9ae4e80',1,'GXPEngine.Transformable.SetScaleXY(float scaleX, float scaleY)'],['../class_g_x_p_engine_1_1_transformable.html#aead4d1f0fd78242a91318599ebfc1908',1,'GXPEngine.Transformable.SetScaleXY(float scale)']]],
  ['settings_110',['Settings',['../class_g_x_p_engine_1_1_settings.html',1,'GXPEngine']]],
  ['setviewport_111',['SetViewport',['../class_g_x_p_engine_1_1_game.html#afecde817f37c96e76d26593c7fcac853',1,'GXPEngine::Game']]],
  ['setxy_112',['SetXY',['../class_g_x_p_engine_1_1_transformable.html#a21fbd124df79d5fda5b98c49251cbdab',1,'GXPEngine::Transformable']]],
  ['showmouse_113',['ShowMouse',['../class_g_x_p_engine_1_1_game.html#a2f0f1eb7d0ba0c275deaef45421b8544',1,'GXPEngine::Game']]],
  ['sound_114',['Sound',['../class_g_x_p_engine_1_1_sound.html',1,'GXPEngine.Sound'],['../class_g_x_p_engine_1_1_sound.html#a0f1aaede78ecba23937a82ed53272197',1,'GXPEngine.Sound.Sound()']]],
  ['soundchannel_115',['SoundChannel',['../class_g_x_p_engine_1_1_sound_channel.html',1,'GXPEngine']]],
  ['sprite_116',['Sprite',['../class_g_x_p_engine_1_1_sprite.html',1,'GXPEngine.Sprite'],['../class_g_x_p_engine_1_1_sprite.html#a22b8dd09f5a35aa1a869ad37c995f3e5',1,'GXPEngine.Sprite.Sprite(System.Drawing.Bitmap bitmap, bool addCollider=true)'],['../class_g_x_p_engine_1_1_sprite.html#ac4e833f3e5fd010030fdbd1f55359a40',1,'GXPEngine.Sprite.Sprite(string filename, bool keepInCache=false, bool addCollider=true)']]],
  ['start_117',['Start',['../class_g_x_p_engine_1_1_game.html#a60cfaccee44dd4badd8629bcd9936beb',1,'GXPEngine::Game']]],
  ['stepdelegate_118',['StepDelegate',['../class_g_x_p_engine_1_1_game.html#a4d1f2cf034dc8d50480f94ea0da11fb4',1,'GXPEngine::Game']]],
  ['stop_119',['Stop',['../class_g_x_p_engine_1_1_sound_channel.html#aa398367364ddf786a89587ce1823ad42',1,'GXPEngine::SoundChannel']]]
];
