var searchData=
[
  ['timeofimpact_256',['TimeOfImpact',['../class_g_x_p_engine_1_1_game_object.html#a74d97832cabf7232e1ab1ca865631256',1,'GXPEngine::GameObject']]],
  ['transformdirection_257',['TransformDirection',['../class_g_x_p_engine_1_1_transformable.html#a61e67c44ee049e8da13ada057c8643aa',1,'GXPEngine.Transformable.TransformDirection()'],['../class_g_x_p_engine_1_1_game_object.html#a99734fab6b98d0aa2210316e0d53f5fd',1,'GXPEngine.GameObject.TransformDirection()']]],
  ['transformpoint_258',['TransformPoint',['../class_g_x_p_engine_1_1_transformable.html#a87286aa8c7798447591917f1a20b0d0c',1,'GXPEngine.Transformable.TransformPoint()'],['../class_g_x_p_engine_1_1_game_object.html#a749ca5e7b0beb2032a70e4fc38e7382f',1,'GXPEngine.GameObject.TransformPoint()']]],
  ['translate_259',['Translate',['../class_g_x_p_engine_1_1_transformable.html#a04e83b5d8974d541029c1ceada349173',1,'GXPEngine::Transformable']]],
  ['turn_260',['Turn',['../class_g_x_p_engine_1_1_transformable.html#a23a7f952df8288e594d52ac5aa5be7eb',1,'GXPEngine::Transformable']]]
];
