var searchData=
[
  ['objectgroup_170',['ObjectGroup',['../class_tiled_map_parser_1_1_object_group.html',1,'TiledMapParser']]]
];
