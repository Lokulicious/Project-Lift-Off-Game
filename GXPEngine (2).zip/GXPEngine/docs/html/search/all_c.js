var searchData=
[
  ['nextframe_81',['NextFrame',['../class_g_x_p_engine_1_1_animation_sprite.html#acfbbf3c0cefeb86eab1ed5a567547177',1,'GXPEngine::AnimationSprite']]],
  ['now_82',['now',['../class_g_x_p_engine_1_1_time.html#aba5361de96ecaf3b3f3fddfeef5d2271',1,'GXPEngine::Time']]]
];
