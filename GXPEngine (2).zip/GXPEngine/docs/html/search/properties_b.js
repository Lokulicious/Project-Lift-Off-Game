var searchData=
[
  ['texture_290',['texture',['../class_g_x_p_engine_1_1_sprite.html#a48c7dbc7d4d7903e23e23ee42f934df6',1,'GXPEngine::Sprite']]],
  ['time_291',['time',['../class_g_x_p_engine_1_1_time.html#acc02a410574f6e3c52b32564ce1b481d',1,'GXPEngine::Time']]]
];
