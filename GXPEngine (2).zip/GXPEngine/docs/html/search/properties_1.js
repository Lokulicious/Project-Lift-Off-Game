var searchData=
[
  ['color_268',['color',['../class_g_x_p_engine_1_1_sprite.html#a6cf62404b2bca9e8eedcff197e8e594c',1,'GXPEngine::Sprite']]],
  ['currentframe_269',['currentFrame',['../class_g_x_p_engine_1_1_animation_sprite.html#a6b798ae687736031661d59764ccb0fb3',1,'GXPEngine::AnimationSprite']]]
];
