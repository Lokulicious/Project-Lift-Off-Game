var class_g_x_p_engine_1_1_pivot =
[
    [ "Pivot", "class_g_x_p_engine_1_1_pivot.html#a2655cff2389869ce98339a6a97423ea3", null ]
];